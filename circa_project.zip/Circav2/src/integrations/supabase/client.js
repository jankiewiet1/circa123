// Re-export from TypeScript for ES module compatibility
export { supabase } from './client.ts'; 