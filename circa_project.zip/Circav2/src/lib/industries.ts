
export const industries = [
  { value: "manufacturing", label: "Manufacturing" },
  { value: "information_technology", label: "Information Technology" },
  { value: "healthcare", label: "Healthcare" },
  { value: "finance", label: "Finance & Banking" },
  { value: "retail", label: "Retail & E-commerce" },
  { value: "energy", label: "Energy & Utilities" },
  { value: "transportation", label: "Transportation & Logistics" },
  { value: "construction", label: "Construction & Real Estate" },
  { value: "agriculture", label: "Agriculture & Food Production" },
  { value: "education", label: "Education" },
  { value: "hospitality", label: "Hospitality & Tourism" },
  { value: "media", label: "Media & Entertainment" },
  { value: "telecommunications", label: "Telecommunications" },
  { value: "professional_services", label: "Professional Services" },
  { value: "nonprofit", label: "Nonprofit & NGO" }
];
