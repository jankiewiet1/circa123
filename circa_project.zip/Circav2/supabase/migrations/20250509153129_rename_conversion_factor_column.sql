ALTER TABLE public.emission_factors RENAME COLUMN co2_factor TO GHG_Conversion_Factor;
